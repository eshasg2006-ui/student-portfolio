/* =========================================================
   University Event Management System - script.js
   Student: Isha Ali | Roll No: BSITS24BSR23
   All data is stored in the browser's localStorage (demo only).
   ========================================================= */

// ---------- Sample events ----------
const sampleEvents = [
  { id: 1, name: "Web Development Bootcamp", category: "Workshop", date: "2026-11-05", time: "10:00", location: "IT Lab 3", image: "images/workshop.jpg", description: "Hands-on workshop on HTML, CSS and JavaScript for beginners." },
  { id: 2, name: "AI & Data Science Seminar", category: "Seminar", date: "2026-11-12", time: "11:30", location: "Main Auditorium", image: "images/seminar.jpg", description: "Industry experts talk about the future of artificial intelligence." },
  { id: 3, name: "Inter-Department Cricket Cup", category: "Sports", date: "2026-11-18", time: "09:00", location: "University Ground", image: "images/sports.jpg", description: "Cheer for your department in the annual cricket tournament." },
  { id: 4, name: "Cultural Night 2026", category: "Cultural", date: "2026-11-25", time: "18:00", location: "Open Air Theatre", image: "images/cultural.jpg", description: "Music, traditional dance and food stalls from all over the country." },
  { id: 5, name: "Coding Competition", category: "Competition", date: "2026-12-02", time: "14:00", location: "CS Block, Lab 1", image: "images/workshop.jpg", description: "Solve programming problems in teams of two and win exciting prizes." },
  { id: 6, name: "Career Guidance Seminar", category: "Seminar", date: "2026-12-08", time: "12:00", location: "Seminar Hall B", image: "images/seminar.jpg", description: "Learn about CV writing, interviews and internships." },
];

// ---------- localStorage helpers ----------
function loadData(key, fallback) {
  const saved = localStorage.getItem(key);
  return saved ? JSON.parse(saved) : fallback;
}
function saveData(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

let events = loadData("uems_events", sampleEvents);
let registrations = loadData("uems_registrations", []);
let activeCategory = "All";

// ---------- Small utilities ----------
const $ = (id) => document.getElementById(id);

function escapeHTML(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function formatDate(dateStr) {
  return new Date(dateStr + "T00:00").toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

function formatTime(timeStr) {
  const [h, m] = timeStr.split(":");
  const hour = Number(h);
  return `${hour % 12 || 12}:${m} ${hour >= 12 ? "PM" : "AM"}`;
}

function showToast(message, isError = false) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}

// ---------- Page navigation (hash based) ----------
function showPage() {
  const pageId = location.hash.replace("#", "") || "home";
  document.querySelectorAll(".page").forEach((p) => p.classList.toggle("active", p.id === pageId));
  document.querySelectorAll(".nav-links a").forEach((a) => a.classList.toggle("active", a.dataset.page === pageId));
  $("navLinks").classList.remove("open");
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", showPage);
$("menuToggle").addEventListener("click", () => $("navLinks").classList.toggle("open"));

// ---------- Event cards ----------
function isRegistered(eventId) {
  return registrations.some((r) => r.eventId === eventId);
}

function createEventCard(ev) {
  const button = isRegistered(ev.id)
    ? `<div class="registered-tag"><i class="fa-solid fa-circle-check"></i> Registered</div>`
    : `<button class="btn btn-primary full" onclick="openRegistration(${ev.id})">Register Now</button>`;
  return `
    <article class="event-card">
      <div class="event-img">
        <img src="${escapeHTML(ev.image || "images/seminar.jpg")}" alt="${escapeHTML(ev.name)}" loading="lazy" onerror="this.src='images/seminar.jpg'" />
        <span class="cat">${escapeHTML(ev.category)}</span>
      </div>
      <div class="event-body">
        <h3>${escapeHTML(ev.name)}</h3>
        <div class="meta">
          <span><i class="fa-regular fa-calendar"></i> ${formatDate(ev.date)}</span>
          <span><i class="fa-regular fa-clock"></i> ${formatTime(ev.time)}</span>
          <span><i class="fa-solid fa-location-dot"></i> ${escapeHTML(ev.location)}</span>
        </div>
        <p class="desc">${escapeHTML(ev.description)}</p>
        ${button}
      </div>
    </article>`;
}

function renderEvents() {
  const search = $("searchInput").value.trim().toLowerCase();
  const filtered = events.filter((ev) => {
    const matchCategory = activeCategory === "All" || ev.category === activeCategory;
    const text = `${ev.name} ${ev.location} ${ev.description}`.toLowerCase();
    return matchCategory && text.includes(search);
  });
  $("eventsGrid").innerHTML = filtered.map(createEventCard).join("");
  $("noEvents").hidden = filtered.length > 0;
}

function renderHighlights() {
  const upcoming = [...events].sort((a, b) => a.date.localeCompare(b.date)).slice(0, 3);
  $("highlightsGrid").innerHTML = upcoming.map(createEventCard).join("");
}

$("searchInput").addEventListener("input", renderEvents);
document.querySelectorAll(".filter-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".filter-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    activeCategory = btn.dataset.category;
    renderEvents();
  });
});

// ---------- Registration ----------
function openRegistration(eventId) {
  const ev = events.find((e) => e.id === eventId);
  $("regEventId").value = eventId;
  $("modalEventName").textContent = ev.name;
  $("regForm").reset();
  $("regError").textContent = "";
  $("regModal").classList.add("open");
}
$("closeModal").addEventListener("click", () => $("regModal").classList.remove("open"));
$("regModal").addEventListener("click", (e) => { if (e.target.id === "regModal") $("regModal").classList.remove("open"); });

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

$("regForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const name = $("rName").value.trim();
  const roll = $("rRoll").value.trim().toUpperCase();
  const email = $("rEmail").value.trim();
  const dept = $("rDept").value;
  const eventId = Number($("regEventId").value);

  // Validation
  let error = "";
  if (name.length < 3) error = "Please enter your full name (at least 3 characters).";
  else if (!/^[A-Z0-9-]{5,20}$/.test(roll)) error = "Roll number must be 5–20 letters/numbers.";
  else if (!emailPattern.test(email)) error = "Please enter a valid email address.";
  else if (!dept) error = "Please select your department.";
  else if (registrations.some((r) => r.eventId === eventId && r.roll === roll)) error = "This roll number is already registered for this event.";

  if (error) { $("regError").textContent = error; return; }

  registrations.push({ id: Date.now(), eventId, name, roll, email, dept, registeredAt: new Date().toISOString() });
  saveData("uems_registrations", registrations);
  $("regModal").classList.remove("open");
  showToast(`🎉 Success! ${name}, you are registered.`);
  renderAll();
});

function renderRegistrations() {
  const list = $("registrationsList");
  if (registrations.length === 0) {
    list.innerHTML = `<p class="empty">You haven't registered for any events yet. <a href="#events">Browse events</a></p>`;
    return;
  }
  list.innerHTML = registrations.map((r) => {
    const ev = events.find((e) => e.id === r.eventId);
    const title = ev ? ev.name : "Event removed";
    const when = ev ? `${formatDate(ev.date)} · ${formatTime(ev.time)} · ${escapeHTML(ev.location)}` : "";
    return `
      <div class="reg-item">
        <div>
          <h4>${escapeHTML(title)}</h4>
          <p>${when}</p>
          <p>${escapeHTML(r.name)} · ${escapeHTML(r.roll)} · ${escapeHTML(r.dept)}</p>
        </div>
        <button class="btn btn-danger btn-small" onclick="cancelRegistration(${r.id})">Cancel</button>
      </div>`;
  }).join("");
}

function cancelRegistration(regId) {
  if (!confirm("Cancel this registration?")) return;
  registrations = registrations.filter((r) => r.id !== regId);
  saveData("uems_registrations", registrations);
  showToast("Registration cancelled.");
  renderAll();
}

// ---------- Admin dashboard (demo) ----------
function renderAdmin() {
  $("adminTable").innerHTML = events.map((ev) => {
    const count = registrations.filter((r) => r.eventId === ev.id).length;
    return `
      <tr>
        <td>${escapeHTML(ev.name)}</td>
        <td>${escapeHTML(ev.category)}</td>
        <td>${formatDate(ev.date)}</td>
        <td>${count}</td>
        <td><div class="actions">
          <button class="btn btn-secondary btn-small" onclick="editEvent(${ev.id})"><i class="fa-solid fa-pen"></i></button>
          <button class="btn btn-danger btn-small" onclick="deleteEvent(${ev.id})"><i class="fa-solid fa-trash"></i></button>
        </div></td>
      </tr>`;
  }).join("");
}

function resetEventForm() {
  $("eventForm").reset();
  $("eventId").value = "";
  $("eventFormTitle").textContent = "Add New Event";
  $("eventSubmitBtn").textContent = "Add Event";
  $("cancelEdit").hidden = true;
  $("eventFormError").textContent = "";
}

function editEvent(id) {
  const ev = events.find((e) => e.id === id);
  $("eventId").value = ev.id;
  $("evName").value = ev.name;
  $("evCategory").value = ev.category;
  $("evDate").value = ev.date;
  $("evTime").value = ev.time;
  $("evLocation").value = ev.location;
  $("evImage").value = ev.image;
  $("evDescription").value = ev.description;
  $("eventFormTitle").textContent = "Edit Event";
  $("eventSubmitBtn").textContent = "Save Changes";
  $("cancelEdit").hidden = false;
  $("eventForm").scrollIntoView({ behavior: "smooth" });
}

function deleteEvent(id) {
  if (!confirm("Delete this event and its registrations?")) return;
  events = events.filter((e) => e.id !== id);
  registrations = registrations.filter((r) => r.eventId !== id);
  saveData("uems_events", events);
  saveData("uems_registrations", registrations);
  showToast("Event deleted.");
  renderAll();
}

$("cancelEdit").addEventListener("click", resetEventForm);

$("eventForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const data = {
    name: $("evName").value.trim(),
    category: $("evCategory").value,
    date: $("evDate").value,
    time: $("evTime").value,
    location: $("evLocation").value.trim(),
    image: $("evImage").value.trim() || "images/seminar.jpg",
    description: $("evDescription").value.trim(),
  };
  if (!data.name || !data.date || !data.time || !data.location || !data.description) {
    $("eventFormError").textContent = "Please fill in all required fields.";
    return;
  }
  const editId = Number($("eventId").value);
  if (editId) {
    events = events.map((ev) => (ev.id === editId ? { ...ev, ...data } : ev));
    showToast("Event updated.");
  } else {
    events.push({ id: Date.now(), ...data });
    showToast("Event added.");
  }
  saveData("uems_events", events);
  resetEventForm();
  renderAll();
});

// ---------- Contact form ----------
$("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const name = $("cName").value.trim();
  const email = $("cEmail").value.trim();
  const message = $("cMessage").value.trim();
  let error = "";
  if (name.length < 3) error = "Please enter your name.";
  else if (!emailPattern.test(email)) error = "Please enter a valid email.";
  else if (message.length < 10) error = "Message must be at least 10 characters.";
  $("contactError").textContent = error;
  if (error) return;
  e.target.reset();
  showToast("Thank you! Your message has been received (demo).");
});

// ---------- Render everything ----------
function renderStats() {
  ["homeTotalEvents", "adminTotalEvents"].forEach((id) => ($(id).textContent = events.length));
  ["homeTotalRegs", "adminTotalRegs"].forEach((id) => ($(id).textContent = registrations.length));
}

function renderAll() {
  renderStats();
  renderHighlights();
  renderEvents();
  renderRegistrations();
  renderAdmin();
}

renderAll();
showPage();
